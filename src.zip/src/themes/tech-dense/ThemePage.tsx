import type { ThemePageProps } from "../types";
function Section({
  id,
  title,
  children,
  show = true,
  alt = false,
}: {
  id: string;
  title: string;
  children?: React.ReactNode;
  show?: boolean;
  alt?: boolean;
}) {
  if (!show) return null;
  return (
    <section
      id={id}
      className={`mx-auto max-w-6xl px-6 py-14 ${alt ? "border-l-2 border-cyan-400" : "border-b border-cyan-400/20"}`}
    >
      <p className="text-xs uppercase tracking-[.25em] text-cyan-300">
        {title}
      </p>
      <div className="mt-5">{children}</div>
    </section>
  );
}
export function ThemePage({ config, profile, selection }: ThemePageProps) {
  const alt = Object.values(selection).includes("alt");
  return (
    <main className="font-mono">
      <nav className="mx-auto flex max-w-6xl justify-between px-6 py-5">
        <a href="#hero">{config.name || profile.username}</a>
        <span className="opacity-50">/index</span>
      </nav>
      <Section id="hero" title="// identity">
        <h1 className="text-4xl font-bold text-cyan-300 md:text-7xl">
          {config.headline || config.name || "Build useful things."}
        </h1>
        <p className="mt-5 max-w-2xl opacity-70">{config.about}</p>
      </Section>
      <Section id="about" title="// about" show={!!config.about} alt={alt}>
        <p className="max-w-3xl leading-8 opacity-80">{config.about}</p>
      </Section>
      <Section id="skills" title="// stack" show={!!config.skills?.length}>
        <div className="flex flex-wrap gap-2">
          {config.skills?.map((x) => (
            <span
              key={x.id || x.name}
              className="border border-cyan-300/30 px-3 py-2"
            >
              {x.name}
            </span>
          ))}
        </div>
      </Section>
      <Section
        id="projects"
        title="// projects"
        show={!!config.projects?.length}
      >
        {config.projects?.map((x) => (
          <article
            key={x.id || x.title}
            className="border-b border-cyan-300/20 py-4"
          >
            <b>{x.title}</b>
            <p className="mt-1 opacity-60">{x.description}</p>
          </article>
        ))}
      </Section>
      <Section
        id="experience"
        title="// experience"
        show={!!config.experience?.length}
      >
        {config.experience?.map((x) => (
          <p key={x.id || x.company} className="py-2">
            {x.role} @ {x.company}
          </p>
        ))}
      </Section>
      <Section
        id="education"
        title="// education"
        show={!!config.education?.length}
      >
        {config.education?.map((x) => (
          <p key={x.id || x.institution} className="py-2">
            {x.degree} {x.field} @ {x.institution}
          </p>
        ))}
      </Section>
      <Section
        id="certificates"
        title="// certificates"
        show={!!config.certificates?.length}
      >
        {config.certificates?.map((x) => (
          <p key={x.id || x.name} className="py-2">
            {x.name} · {x.issuer}
          </p>
        ))}
      </Section>
      <Section id="contact" title="// contact">
        <div className="flex gap-4">
          {config.githubUrl && <a href={config.githubUrl}>GitHub</a>}
          {config.linkedinUrl && <a href={config.linkedinUrl}>LinkedIn</a>}
        </div>
      </Section>
      <footer className="mx-auto max-w-6xl px-6 py-10 text-xs opacity-60">
        {config.name || profile.username}
        {!profile.isPremium && (
          <span className="float-right">Built with OrixaAi</span>
        )}
      </footer>
    </main>
  );
}
