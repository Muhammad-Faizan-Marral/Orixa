import type { ThemeSectionProps } from "../../../types";
import { HeroDefault } from "./HeroDefault";
import { HeroAlt } from "./HeroAlt";
export const variants = { default: HeroDefault, alt: HeroAlt } as const;
export function Hero({
  variant = "default",
  ...props
}: ThemeSectionProps & { variant?: string }) {
  const C = variants[variant as keyof typeof variants] || HeroDefault;
  return <C {...props} />;
}
