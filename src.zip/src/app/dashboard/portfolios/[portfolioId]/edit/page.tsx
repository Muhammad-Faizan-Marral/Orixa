import { notFound } from "next/navigation";
import Link from "next/link";

import { requireProfile } from "@/lib/auth/require-profile";
import { requireUser } from "@/lib/auth/require-user";

import { portfolioService } from "@/services/portfolio/portfolio.service";
import { PortfolioWizard } from "@/features/portfolio/components/portfolio-wizard";

type EditPortfolioPageProps = {
  params: Promise<{
    portfolioId: string;
  }>;
};

export default async function EditPortfolioPage({
  params,
}: EditPortfolioPageProps) {
  await requireUser();
  const profile = await requireProfile();
  const { portfolioId } = await params;

  const result = await portfolioService.getPortfolioWithData(
    portfolioId,
    profile.id,
  );

  if (!result) {
    notFound();
  }

  const isNew =
    result.portfolio.status === "draft" &&
    !result.data?.name &&
    !result.data?.headline &&
    !(result.data?.skills && (result.data.skills as unknown[]).length) &&
    !(result.data?.projects && (result.data.projects as unknown[]).length);

  return (
    <div className="space-y-6 p-6">
      <Link
        href={`/dashboard/portfolios/${portfolioId}`}
        className="text-small inline-flex items-center gap-1 hover:text-foreground"
      >
        ← Back to portfolio
      </Link>

      <PortfolioWizard
        portfolio={result.portfolio}
        data={result.data}
        isNew={isNew}
      />
    </div>
  );
}
