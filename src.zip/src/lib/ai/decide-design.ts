import {
  SECTION_VARIANTS,
  DEFAULT_COMPONENT_SELECTION,
  DEFAULT_DESIGN_PREFERENCES,
  variantsPromptBlock,
  type ComponentSelection,
} from "@/features/portfolio/component-variants";
import { generateGeminiText, parseGeminiJson } from "@/lib/ai/gemini";

export type DesignDecision = {
  componentSelection: ComponentSelection;
  designPreferences: typeof DEFAULT_DESIGN_PREFERENCES;
};

const FALLBACK: DesignDecision = {
  componentSelection: DEFAULT_COMPONENT_SELECTION,
  designPreferences: DEFAULT_DESIGN_PREFERENCES,
};

function randomFrom<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]!;
}

/** Prompt blank ho to local random (no API cost) */
export function randomDesignDecision(): DesignDecision {
  const { SECTION_VARIANTS } =require("@/features/portfolio/component-variants") as typeof import("@/features/portfolio/component-variants");

  const componentSelection = {
    hero: { enabled: true, variant: randomFrom(SECTION_VARIANTS.hero) },
    about: { enabled: true, variant: randomFrom(SECTION_VARIANTS.about) },
    skills: { enabled: true, variant: randomFrom(SECTION_VARIANTS.skills) },
    projects: { enabled: true, variant: randomFrom(SECTION_VARIANTS.projects) },
    experience: {
      enabled: true,
      variant: randomFrom(SECTION_VARIANTS.experience),
    },
    education: {
      enabled: true,
      variant: randomFrom(SECTION_VARIANTS.education),
    },
    certificates: {
      enabled: true,
      variant: randomFrom(SECTION_VARIANTS.certificates),
    },
    contact: { enabled: true, variant: randomFrom(SECTION_VARIANTS.contact) },
    footer: { enabled: true, variant: randomFrom(SECTION_VARIANTS.footer) },
  } satisfies ComponentSelection;

  const accents = ["#6c5cff", "#22d3ee", "#34d399", "#fbbf24", "#fb7185"];
  const fonts = ["Inter", "Geist", "Poppins", "Roboto"];

  return {
    componentSelection,
    designPreferences: {
      themeMode: Math.random() > 0.5 ? "dark" : "light",
      layout: randomFrom(["standard", "wide", "centered"] as const),
      accentColor: randomFrom(accents),
      fontFamily: randomFrom(fonts),
      borderRadius: randomFrom(["none", "small", "medium", "large"] as const),
      cardStyle: randomFrom(["flat", "bordered", "elevated"] as const),
    },
  };
}

export async function decideDesignWithGemini(params: {
  prompt: string;
  headline?: string;
  about?: string;
}): Promise<{
  decision: DesignDecision;
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
  usedAi: boolean;
}> {
  const userPrompt = (params.prompt ?? "").trim();

  if (!userPrompt) {
    return {
      decision: randomDesignDecision(),
      inputTokens: 0,
      outputTokens: 0,
      latencyMs: 0,
      usedAi: false,
    };
  }

  const system = `You pick portfolio layout variants and design tokens for Orixa AI.
Return ONLY JSON. Variants must be from the allowed lists.`;

  const prompt = `User design prompt: """${userPrompt.slice(0, 500)}"""
Headline: ${params.headline ?? ""}
About (snippet): ${(params.about ?? "").slice(0, 300)}

Allowed variants:
${variantsPromptBlock()}

Return JSON:
{
  "componentSelection": {
    "hero": { "enabled": true, "variant": "modern" },
    "about": { "enabled": true, "variant": "default" },
    "skills": { "enabled": true, "variant": "grid" },
    "projects": { "enabled": true, "variant": "cards" },
    "experience": { "enabled": true, "variant": "timeline" },
    "education": { "enabled": true, "variant": "simple" },
    "certificates": { "enabled": true, "variant": "simple" },
    "contact": { "enabled": true, "variant": "form" },
    "footer": { "enabled": true, "variant": "minimal" }
  },
  "designPreferences": {
    "themeMode": "dark",
    "layout": "standard",
    "accentColor": "#6c5cff",
    "fontFamily": "Inter",
    "borderRadius": "medium",
    "cardStyle": "bordered"
  }
}`;

  try {
    const result = await generateGeminiText({
      system,
      prompt,
      temperature: 0.5,
      maxOutputTokens: 1024,
    });

    const parsed = parseGeminiJson<DesignDecision>(result.text);

    return {
      decision: {
        componentSelection:
          parsed.componentSelection ?? FALLBACK.componentSelection,
        designPreferences: {
          ...FALLBACK.designPreferences,
          ...(parsed.designPreferences ?? {}),
        },
      },
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      latencyMs: result.latencyMs,
      usedAi: true,
    };
  } catch {
    return {
      decision: randomDesignDecision(),
      inputTokens: 0,
      outputTokens: 0,
      latencyMs: 0,
      usedAi: false,
    };
  }
}
