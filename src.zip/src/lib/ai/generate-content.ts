// Server-only module: only import this from server actions/services.
// (Not using the `server-only` package since it isn't in this project's dependencies.)

const AI_MODEL = "claude-sonnet-4-6";

export type AiAssistField =
  | "headline"
  | "about"
  | "project_description"
  | "experience_description";

const FIELD_INSTRUCTIONS: Record<AiAssistField, string> = {
  headline:
    "Write a short, confident professional headline (max 12 words). No quotes, no emojis, no trailing period.",
  about:
    "Rewrite this into a warm, confident 3-5 sentence 'About' section for a portfolio site, first person.",
  project_description:
    "Rewrite this project description into 2-3 punchy sentences a recruiter would find impressive. First person or neutral, no marketing fluff.",
  experience_description:
    "Rewrite these job responsibilities into 2-4 concise, achievement-oriented bullet-style sentences.",
};

export interface AiGenerateResult {
  text: string;
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
}

/**
 * Calls the configured AI provider to assist with a single portfolio field.
 * Requires ANTHROPIC_API_KEY to be set in the server environment.
 */
export async function generateAssistedText(_params: {
  field: AiAssistField;
  currentText: string;
  context?: string;
}): Promise<AiGenerateResult> {
  throw new Error(
    "Field-level AI is disabled. Use resume parse / finalize flow instead.",
  );
}