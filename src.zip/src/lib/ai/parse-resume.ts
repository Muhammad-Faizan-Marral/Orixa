import { generateGeminiText, parseGeminiJson } from "@/lib/ai/gemini";

export type ParsedResumeData = {
  name: string;
  headline: string;
  about: string;
  phone: string;
  linkedinUrl: string;
  githubUrl: string;
  skills: { name: string; level?: string }[];
  experience: {
    company: string;
    role: string;
    location?: string;
    startDate?: string;
    endDate?: string;
    current?: boolean;
    description?: string;
  }[];
  projects: {
    title: string;
    description?: string;
    url?: string;
    technologies?: string[];
  }[];
  education: {
    institution: string;
    degree?: string;
    field?: string;
    startDate?: string;
    endDate?: string;
    description?: string;
  }[];
  certificates: {
    name: string;
    issuer?: string;
    issueDate?: string;
    credentialUrl?: string;
  }[];
};

const SYSTEM = `You are a portfolio data extractor. You receive raw text from a PDF resume.
Rules:
- Rewrite all text into clean, professional English (do NOT copy verbatim if awkward).
- Dates: prefer MM/YYYY or DD/MM/YYYY. Use "Present" for ongoing roles.
- If a field is missing, use empty string or empty array.
- skills: real skill names only (min 2 chars). No garbage like "re".
- projects technologies: short tech names array.
- Return ONLY valid JSON matching the schema. No markdown.`;

const SCHEMA_HINT = `{
  "name": "string",
  "headline": "string",
  "about": "string",
  "phone": "string",
  "linkedinUrl": "string",
  "githubUrl": "string",
  "skills": [{ "name": "string", "level": "string" }],
  "experience": [{
    "company": "string",
    "role": "string",
    "location": "string",
    "startDate": "string",
    "endDate": "string",
    "current": false,
    "description": "string"
  }],
  "projects": [{
    "title": "string",
    "description": "string",
    "url": "string",
    "technologies": ["string"]
  }],
  "education": [{
    "institution": "string",
    "degree": "string",
    "field": "string",
    "startDate": "string",
    "endDate": "string",
    "description": "string"
  }],
  "certificates": [{
    "name": "string",
    "issuer": "string",
    "issueDate": "string",
    "credentialUrl": "string"
  }],
  "isValidResume": true,
  "errorMessage": ""
}`;

export async function extractTextFromPdf(buffer: Buffer): Promise<string> {
  const pdfModule = await import("pdf-parse");
  // Bypass TS ESM type check safely for Turbopack
  const pdf = (pdfModule.default ?? pdfModule) as unknown as (
    dataBuffer: Buffer
  ) => Promise<{ text: string }>;

  const result = await pdf(buffer);
  return (result.text ?? "").trim();
}

export async function parseResumeWithGemini(rawText: string): Promise<{
  data: ParsedResumeData | null;
  isValid: boolean;
  errorMessage: string;
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
}> {
  if (!rawText || rawText.length < 40) {
    return {
      data: null,
      isValid: false,
      errorMessage:
        "Resume text is empty or too short. Please upload a valid PDF resume.",
      inputTokens: 0,
      outputTokens: 0,
      latencyMs: 0,
    };
  }

  // Cap text to control cost
  const clipped = rawText.slice(0, 14000);

  const prompt = `Extract and rewrite portfolio fields from this resume text.

JSON schema:
${SCHEMA_HINT}

If this is NOT a resume (empty, garbage, wrong file), set isValidResume=false and errorMessage explaining the issue in simple English or Roman Urdu mix.

Resume text:
"""
${clipped}
"""`;

  const result = await generateGeminiText({
    system: SYSTEM,
    prompt,
    temperature: 0.3,
    maxOutputTokens: 4096,
  });

  type GeminiResumeResponse = ParsedResumeData & {
    isValidResume?: boolean;
    errorMessage?: string;
  };

  let parsed: GeminiResumeResponse;
  try {
    parsed = parseGeminiJson<GeminiResumeResponse>(result.text);
  } catch {
    return {
      data: null,
      isValid: false,
      errorMessage:
        "AI could not read this resume. Try another PDF or fill manually.",
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      latencyMs: result.latencyMs,
    };
  }

  if (parsed.isValidResume === false) {
    return {
      data: null,
      isValid: false,
      errorMessage:
        parsed.errorMessage ||
        "Aap ka resume sahi nahi hai ya empty hai. Dobara valid PDF upload karein.",
      inputTokens: result.inputTokens,
      outputTokens: result.outputTokens,
      latencyMs: result.latencyMs,
    };
  }

  const data: ParsedResumeData = {
    name: parsed.name ?? "",
    headline: parsed.headline ?? "",
    about: parsed.about ?? "",
    phone: parsed.phone ?? "",
    linkedinUrl: parsed.linkedinUrl ?? "",
    githubUrl: parsed.githubUrl ?? "",
    skills: Array.isArray(parsed.skills) ? parsed.skills : [],
    experience: Array.isArray(parsed.experience) ? parsed.experience : [],
    projects: Array.isArray(parsed.projects) ? parsed.projects : [],
    education: Array.isArray(parsed.education) ? parsed.education : [],
    certificates: Array.isArray(parsed.certificates) ? parsed.certificates : [],
  };

  return {
    data,
    isValid: true,
    errorMessage: "",
    inputTokens: result.inputTokens,
    outputTokens: result.outputTokens,
    latencyMs: result.latencyMs,
  };
}
