const GEMINI_MODEL = "gemini-1.5-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

export type GeminiUsage = {
  inputTokens: number;
  outputTokens: number;
  latencyMs: number;
};

export type GeminiTextResult = {
  text: string;
} & GeminiUsage;

function getApiKey() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error(
      "GEMINI_API_KEY is not configured. AI features are disabled.",
    );
  }
  return key;
}

/**
 * Call Gemini 1.5 Flash. Returns raw text response.
 */

export async function generateGeminiText(params: {
  system?: string;
  prompt: string;
  temperature?: number;
  maxOutputTokens?: number;
}): Promise<GeminiTextResult> {
  const apiKey = getApiKey();
  const startedAt = Date.now();

  const body: Record<string, unknown> = {
    contents: [
      {
        role: "user",
        parts: [{ text: params.prompt }],
      },
    ],
    generationConfig: {
      temperature: params.temperature ?? 0.4,
      maxOutputTokens: params.maxOutputTokens ?? 4096,
      responseMimeType: "application/json",
    },
  };

  if (params.system) {
    body.systemInstruction = {
      parts: [{ text: params.system }],
    };
  }

  const response = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

  const latencyMs = Date.now() - startedAt;

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Gemini error (${response.status}): ${errorBody}`);
  }

  const data = await response.json();

  const text =
    data?.candidates?.[0]?.content?.parts
      ?.map((p: { text?: string }) => p.text ?? "")
      .join("")
      ?.trim() ?? "";

  const usage = data?.usageMetadata ?? {};

  return {
    text,
    inputTokens: usage.promptTokenCount ?? 0,
    outputTokens: usage.candidatesTokenCount ?? 0,
    latencyMs,
  };
}

/** Safe JSON parse from model output */
export function parseGeminiJson<T>(raw: string): T {
  const cleaned = raw
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  return JSON.parse(cleaned) as T;
}
