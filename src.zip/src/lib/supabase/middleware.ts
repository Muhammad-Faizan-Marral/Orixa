import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Routes that require an authenticated user.
 * Anything under these prefixes redirects to /auth/login when signed out.
 */
const PROTECTED_PREFIXES = ["/dashboard", "/onboarding"];

/**
 * Routes an already-authenticated user shouldn't see again.
 * /auth/callback and /auth/reset-password are intentionally excluded:
 * callback must always run, and reset-password relies on a short-lived
 * recovery session that looks "authenticated" but isn't a normal login.
 */
const GUEST_ONLY_ROUTES = ["/auth/login", "/auth/signup", "/auth/forgot-password"];

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({
    request,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },

        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => {
            request.cookies.set(name, value);
          });

          response = NextResponse.next({
            request,
          });

          cookiesToSet.forEach(({ name, value, options }) => {
            response.cookies.set(name, value, options);
          });
        },
      },
    },
  );

  // IMPORTANT: do not run any logic between createServerClient and this call.
  // A simple mistake here can make it very hard to debug session issues.
  const { data } = await supabase.auth.getClaims();
  const isAuthenticated = Boolean(data?.claims);

  const { pathname } = request.nextUrl;

  const isProtectedRoute = PROTECTED_PREFIXES.some((prefix) =>
    pathname.startsWith(prefix),
  );

  const isGuestOnlyRoute = GUEST_ONLY_ROUTES.some((route) =>
    pathname.startsWith(route),
  );

  if (isProtectedRoute && !isAuthenticated) {
    const loginUrl = new URL("/auth/login", request.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (isGuestOnlyRoute && isAuthenticated) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // IMPORTANT: always return the `response` object as-is when not redirecting,
  // so the refreshed Supabase cookies are actually written back to the browser.
  return response;
}
