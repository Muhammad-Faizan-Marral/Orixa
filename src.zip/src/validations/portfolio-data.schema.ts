import { z } from "zod";

const optionalString = z.string().trim().optional().or(z.literal(""));

const urlOptional = z
  .string()
  .trim()
  .optional()
  .or(z.literal(""))
  .refine(
    (val) => !val || /^https?:\/\/.+/i.test(val),
    "Must be a valid URL starting with http:// or https://",
  );

const phoneOptional = z
  .string()
  .trim()
  .optional()
  .or(z.literal(""))
  .refine(
    (val) => !val || /^[+]?[\d\s\-()]{7,20}$/.test(val),
    "Invalid phone number",
  );

/* ── Content item schemas (stricter) ── */

export const portfolioProjectSchema = z.object({
  id: z.string(),
  title: z.string().trim().min(2, "Title is too short").max(120),
  description: optionalString,
  url: urlOptional,
  technologies: z.array(z.string().trim().min(1).max(40)).default([]),
  imageUrl: optionalString,
});

export const portfolioExperienceSchema = z.object({
  id: z.string(),
  company: z.string().trim().min(1).max(120),
  role: z.string().trim().min(1).max(120),
  location: optionalString,
  startDate: optionalString,
  endDate: optionalString,
  current: z.boolean().default(false),
  description: optionalString,
});

export const portfolioSkillSchema = z.object({
  id: z.string(),
  name: z
    .string()
    .trim()
    .min(2, "Skill name is too short")
    .max(40, "Skill name is too long")
    .refine(
      (val) => /^[a-zA-Z0-9+#.\- ]+$/.test(val),
      "Skill contains invalid characters",
    ),
  level: optionalString,
});

export const portfolioEducationSchema = z.object({
  id: z.string(),
  institution: z.string().trim().min(1).max(150),
  degree: optionalString,
  field: optionalString,
  startDate: optionalString,
  endDate: optionalString,
  description: optionalString,
});

export const portfolioCertificateSchema = z.object({
  id: z.string(),
  name: z.string().trim().min(1).max(150),
  issuer: optionalString,
  issueDate: optionalString,
  credentialUrl: urlOptional,
});

/* ── AI-controlled (still validated, but not shown in form) ── */

const sectionSelectionSchema = z.object({
  enabled: z.boolean(),
  variant: z.string().min(1),
});

const componentSelectionSchema = z
  .object({
    hero: sectionSelectionSchema.optional(),
    about: sectionSelectionSchema.optional(),
    skills: sectionSelectionSchema.optional(),
    projects: sectionSelectionSchema.optional(),
    experience: sectionSelectionSchema.optional(),
    education: sectionSelectionSchema.optional(),
    certificates: sectionSelectionSchema.optional(),
    contact: sectionSelectionSchema.optional(),
    footer: sectionSelectionSchema.optional(),
  })
  .default({});

const designPreferencesSchema = z
  .object({
    themeMode: z.enum(["light", "dark"]).default("dark"),
    layout: z.enum(["standard", "wide", "centered"]).default("standard"),
    accentColor: z.string().trim().min(1).max(30).default("#6c5cff"),
    fontFamily: z.string().trim().min(1).max(50).default("Inter"),
    borderRadius: z
      .enum(["none", "small", "medium", "large"])
      .default("medium"),
    cardStyle: z.enum(["flat", "bordered", "elevated"]).default("bordered"),
  })
  .default({});

/* ── SEO (only title + description + keywords + noIndex) ── */

const seoSchema = z.object({
  title: z.string().trim().max(70).default(""),
  description: z.string().trim().max(160).default(""),
  keywords: z.array(z.string().trim().max(40)).default([]),
  noIndex: z.boolean().default(false),
});

/* ── Main update schema ── */

export const updatePortfolioDataSchema = z.object({
  portfolioId: z.string().uuid(),

  name: z.string().trim().max(100).default(""),
  prompt: z.string().trim().max(500).default(""),
  avatarUrl: z.string().trim().default(""),
  phone: phoneOptional,
  linkedinUrl: urlOptional,
  githubUrl: urlOptional,

  headline: z.string().trim().max(200).default(""),
  about: z.string().trim().max(5000).default(""),

  projects: z.array(portfolioProjectSchema).default([]),
  experience: z.array(portfolioExperienceSchema).default([]),
  skills: z.array(portfolioSkillSchema).default([]),
  education: z.array(portfolioEducationSchema).default([]),
  certificates: z.array(portfolioCertificateSchema).default([]),

  resumeUrl: z.string().trim().default(""),

  theme: z.string().trim().min(1).max(50).default("minimal"),
  animations: z.boolean().default(true),

  componentSelection: componentSelectionSchema,
  designPreferences: designPreferencesSchema,
  seo: seoSchema.default({}),
});

export type UpdatePortfolioDataInput = z.infer<
  typeof updatePortfolioDataSchema
>;
