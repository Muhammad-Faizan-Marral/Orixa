"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ChangeEvent,
} from "react";
import { useRouter } from "next/navigation";

import { CreationModeSelect } from "../creation-mode-select";
import { WizardProgress } from "../wizard-progress";

import { CONTENT_STEPS } from "../../wizard-steps";
import { parseResumeAction } from "@/actions/portfolio/parse-resume";
import { finalizePortfolioAction } from "@/actions/portfolio/finalize-portfolio";
import { generateAndAttachResume } from "@/actions/portfolio/generate-resume";
import { uploadFile } from "@/actions/profile/upload-file";

import { Button } from "@/components/UI/Button";

import type {
  PortfolioWizardProps,
  CreationMode,
  Experience as ExperienceItem,
  Project as ProjectItem,
  Education as EducationItem,
  Certificate as CertificateItem,
} from "./types";
import { validateStep } from "./validation";
import { isPortfolioEmpty } from "./utils";

// Steps Imports
import {
  BasicsStep,
  ExperienceStep,
  ProjectsStep,
  EducationStep,
  CertificatesStep,
  ResumeStep,
  SeoStep,
} from "./steps";

import type { UpdatePortfolioDataInput } from "@/validations/portfolio-data.schema";

export function PortfolioWizard({
  portfolio,
  data,
  isNew,
}: PortfolioWizardProps) {
  const router = useRouter();

  console.log("[PortfolioWizard] render", {
    portfolioId: portfolio.id,
    isNew,
    hasData: Boolean(data),
    existingResumeUrl: data?.resumeUrl ?? null,
  });

  // ---------------------------------------------------------------------------
  // Creation mode
  // ---------------------------------------------------------------------------

  const [mode, setMode] = useState<CreationMode>("manual");

  // ---------------------------------------------------------------------------
  // Basic information
  // ---------------------------------------------------------------------------

  const [name, setName] = useState(data?.name ?? portfolio.title ?? "");
  const [prompt, setPrompt] = useState(data?.prompt ?? "");

  const [avatarUrl, setAvatarUrl] = useState(data?.avatarUrl ?? "");
  const [phone, setPhone] = useState(data?.phone ?? "");
  const [linkedinUrl, setLinkedinUrl] = useState(data?.linkedinUrl ?? "");
  const [githubUrl, setGithubUrl] = useState(data?.githubUrl ?? "");

  const [headline, setHeadline] = useState(data?.headline ?? "");
  const [about, setAbout] = useState(data?.about ?? "");

  const [skills, setSkills] = useState<string[]>(data?.skills ?? []);

  // ---------------------------------------------------------------------------
  // Portfolio sections
  // ---------------------------------------------------------------------------

  const [experience, setExperience] = useState<ExperienceItem[]>(
    data?.experience ?? [],
  );

  const [projects, setProjects] = useState<ProjectItem[]>(data?.projects ?? []);

  const [education, setEducation] = useState<EducationItem[]>(
    data?.education ?? [],
  );

  const [certificates, setCertificates] = useState<CertificateItem[]>(
    data?.certificates ?? [],
  );

  // ---------------------------------------------------------------------------
  // Resume
  // ---------------------------------------------------------------------------

  const [resumeUrl, setResumeUrl] = useState(data?.resumeUrl ?? "");

  const [hasUploadedResume, setHasUploadedResume] = useState(
    Boolean(data?.resumeUrl),
  );

  const [attachUploadedResume, setAttachUploadedResume] = useState(
    Boolean(data?.resumeUrl),
  );

  const [autoGenerateResume, setAutoGenerateResume] = useState(false);

  const [isParsingResume, setIsParsingResume] = useState(false);
  const [isUploadingResume, setIsUploadingResume] = useState(false);
  const [isGeneratingResume, setIsGeneratingResume] = useState(false);

  // ---------------------------------------------------------------------------
  // SEO
  // ---------------------------------------------------------------------------

  const [seoTitle, setSeoTitle] = useState(
    (data?.seo?.title as string) ?? portfolio.title ?? "",
  );

  const [seoDescription, setSeoDescription] = useState(
    (data?.seo?.description as string) ?? "",
  );

  const [seoKeywords, setSeoKeywords] = useState(
    ((data?.seo?.keywords as string[]) ?? []).join(", "),
  );

  const [seoNoIndex, setSeoNoIndex] = useState(
    (data?.seo?.noIndex as boolean) ?? false,
  );

  // ---------------------------------------------------------------------------
  // Wizard
  // ---------------------------------------------------------------------------

  const [currentStep, setCurrentStep] = useState(0);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ---------------------------------------------------------------------------
  // Existing design data
  // IMPORTANT:
  // Edit mode mein empty {} send nahi karna.
  // Existing componentSelection/designPreferences preserve karni hain.
  // ---------------------------------------------------------------------------

  const existingComponentSelection = useMemo(
    () =>
      (data?.componentSelection as
        | UpdatePortfolioDataInput["componentSelection"]
        | undefined) ?? {},
    [data?.componentSelection],
  );

  const existingDesignPreferences = useMemo(
    () =>
      (data?.designPreferences as
        | UpdatePortfolioDataInput["designPreferences"]
        | undefined) ?? {},
    [data?.designPreferences],
  );

  console.log("[PortfolioWizard] existing design values", {
    componentSelection: existingComponentSelection,
    designPreferences: existingDesignPreferences,
  });

  // ---------------------------------------------------------------------------
  // Prompt lock
  // ---------------------------------------------------------------------------

  const promptLocked = Boolean(data?.prompt && data.prompt.trim().length > 0);

  // ---------------------------------------------------------------------------
  // Initial mode
  // ---------------------------------------------------------------------------

  useEffect(() => {
    if (!isNew && data) {
      console.log("[PortfolioWizard] edit mode detected", {
        portfolioId: portfolio.id,
      });

      setMode("manual");
      return;
    }

    if (isNew && isPortfolioEmpty(data)) {
      console.log("[PortfolioWizard] new empty portfolio detected");
      setMode("manual");
    }
  }, [isNew, data, portfolio.id]);

  // ---------------------------------------------------------------------------
  // Resume file validation
  // ---------------------------------------------------------------------------

  const validateResumeFile = useCallback((file: File) => {
    console.log("[PortfolioWizard] validating resume file", {
      name: file.name,
      type: file.type,
      size: file.size,
    });

    if (file.type !== "application/pdf") {
      console.error("[PortfolioWizard] invalid resume type", {
        type: file.type,
      });

      throw new Error("Only PDF resume files are supported.");
    }

    const maxSize = 5 * 1024 * 1024;

    if (file.size > maxSize) {
      console.error("[PortfolioWizard] resume exceeds max size", {
        size: file.size,
        maxSize,
      });

      throw new Error("Resume must be smaller than 5MB.");
    }

    console.log("[PortfolioWizard] resume file validation passed");
  }, []);

  // ---------------------------------------------------------------------------
  // Resume upload
  // ---------------------------------------------------------------------------

  const handleResumeUpload = useCallback(
    async (file: File) => {
      console.log("[PortfolioWizard] handleResumeUpload started", {
        mode,
        fileName: file.name,
      });

      setError(null);

      try {
        validateResumeFile(file);

        setIsUploadingResume(true);

        // ---------------------------------------------------------------------
        // Manual mode
        // ---------------------------------------------------------------------

        if (mode === "manual") {
          console.log("[PortfolioWizard] manual mode: uploading resume only");

          const result = await uploadFile(file);

          console.log("[PortfolioWizard] manual upload response", result);

          if (!result?.success || !result?.data?.url) {
            throw new Error(result?.error ?? "Failed to upload resume.");
          }

          setResumeUrl(result.data.url);
          setHasUploadedResume(true);
          setAttachUploadedResume(true);
          setAutoGenerateResume(false);

          console.log("[PortfolioWizard] manual resume uploaded", {
            resumeUrl: result.data.url,
          });

          return;
        }

        // ---------------------------------------------------------------------
        // Resume mode
        // ---------------------------------------------------------------------

        console.log(
          "[PortfolioWizard] resume mode: parsing resume before upload",
        );

        setIsParsingResume(true);

        const parseResult = await parseResumeAction(file);

        console.log("[PortfolioWizard] parseResumeAction response", {
          success: parseResult?.success,
          hasData: Boolean(parseResult?.data),
          error: parseResult?.error,
        });

        if (!parseResult?.success || !parseResult?.data) {
          throw new Error(parseResult?.error ?? "Failed to parse resume.");
        }

        const parsed = parseResult.data;

        console.log("[PortfolioWizard] parsed resume data", parsed);

        // ---------------------------------------------------------------------
        // Auto-fill portfolio form
        // ---------------------------------------------------------------------

        if (parsed.name) {
          console.log("[PortfolioWizard] setting parsed name");
          setName(parsed.name);
        }

        if (parsed.phone) {
          console.log("[PortfolioWizard] setting parsed phone");
          setPhone(parsed.phone);
        }

        if (parsed.linkedinUrl) {
          console.log("[PortfolioWizard] setting parsed LinkedIn");
          setLinkedinUrl(parsed.linkedinUrl);
        }

        if (parsed.githubUrl) {
          console.log("[PortfolioWizard] setting parsed GitHub");
          setGithubUrl(parsed.githubUrl);
        }

        if (parsed.headline) {
          console.log("[PortfolioWizard] setting parsed headline");
          setHeadline(parsed.headline);
        }

        if (parsed.about) {
          console.log("[PortfolioWizard] setting parsed about");
          setAbout(parsed.about);
        }

        if (parsed.skills) {
          console.log("[PortfolioWizard] setting parsed skills");
          setSkills(parsed.skills);
        }

        if (parsed.experience) {
          console.log("[PortfolioWizard] setting parsed experience");
          setExperience(parsed.experience);
        }

        if (parsed.projects) {
          console.log("[PortfolioWizard] setting parsed projects");
          setProjects(parsed.projects);
        }

        if (parsed.education) {
          console.log("[PortfolioWizard] setting parsed education");
          setEducation(parsed.education);
        }

        if (parsed.certificates) {
          console.log("[PortfolioWizard] setting parsed certificates");
          setCertificates(parsed.certificates);
        }

        // ---------------------------------------------------------------------
        // Upload original resume
        // ---------------------------------------------------------------------

        console.log("[PortfolioWizard] uploading original parsed resume");

        const uploadResult = await uploadFile(file);

        console.log(
          "[PortfolioWizard] parsed resume upload response",
          uploadResult,
        );

        if (!uploadResult?.success || !uploadResult?.data?.url) {
          throw new Error(uploadResult?.error ?? "Failed to upload resume.");
        }

        setResumeUrl(uploadResult.data.url);
        setHasUploadedResume(true);
        setAttachUploadedResume(true);
        setAutoGenerateResume(false);

        console.log("[PortfolioWizard] resume parsed + uploaded successfully", {
          resumeUrl: uploadResult.data.url,
        });
      } catch (err) {
        console.error("[PortfolioWizard] resume upload failed", err);

        const message =
          err instanceof Error
            ? err.message
            : "Something went wrong while processing the resume.";

        setError(message);
      } finally {
        setIsUploadingResume(false);
        setIsParsingResume(false);

        console.log("[PortfolioWizard] handleResumeUpload finished");
      }
    },
    [mode, validateResumeFile],
  );

  // ---------------------------------------------------------------------------
  // Resume input change
  // ---------------------------------------------------------------------------

  const handleResumeInputChange = useCallback(
    async (event: ChangeEvent<HTMLInputElement>) => {
      console.log("[PortfolioWizard] resume input changed");

      const file = event.target.files?.[0];

      if (!file) {
        console.log("[PortfolioWizard] no resume file selected");
        return;
      }

      await handleResumeUpload(file);

      // Reset input so selecting the same file again triggers change.
      event.target.value = "";
    },
    [handleResumeUpload],
  );

  // ---------------------------------------------------------------------------
  // Resume attach toggle
  // ---------------------------------------------------------------------------

  const handleAttachUploadedResumeChange = useCallback(
    (checked: boolean) => {
      console.log("[PortfolioWizard] attach uploaded resume changed", {
        checked,
        currentResumeUrl: resumeUrl,
      });

      setAttachUploadedResume(checked);

      if (checked) {
        setAutoGenerateResume(false);
      }
    },
    [resumeUrl],
  );

  // ---------------------------------------------------------------------------
  // Auto generate resume toggle
  // ---------------------------------------------------------------------------

  const handleAutoGenerateResumeChange = useCallback((checked: boolean) => {
    console.log("[PortfolioWizard] auto generate resume changed", {
      checked,
    });

    setAutoGenerateResume(checked);

    if (checked) {
      setAttachUploadedResume(false);
    }
  }, []);

  // ---------------------------------------------------------------------------
  // Step validation
  // ---------------------------------------------------------------------------

  const validateCurrentStep = useCallback(() => {
    console.log("[PortfolioWizard] validating current step", {
      currentStep,
      step: CONTENT_STEPS[currentStep],
    });

    const result = validateStep(currentStep, {
      name,
      prompt,
      avatarUrl,
      phone,
      linkedinUrl,
      githubUrl,
      headline,
      about,
      skills,
      experience,
      projects,
      education,
      certificates,
      resumeUrl,
      seoTitle,
      seoDescription,
      seoKeywords,
      seoNoIndex,
    });

    console.log("[PortfolioWizard] validation result", result);

    if (!result.valid) {
      setError(result.error ?? "Please complete this step.");
      return false;
    }

    setError(null);

    return true;
  }, [
    currentStep,
    name,
    prompt,
    avatarUrl,
    phone,
    linkedinUrl,
    githubUrl,
    headline,
    about,
    skills,
    experience,
    projects,
    education,
    certificates,
    resumeUrl,
    seoTitle,
    seoDescription,
    seoKeywords,
    seoNoIndex,
  ]);

  // ---------------------------------------------------------------------------
  // Next step
  // ---------------------------------------------------------------------------

  const handleNext = useCallback(() => {
    console.log("[PortfolioWizard] next button clicked", {
      currentStep,
      totalSteps: CONTENT_STEPS.length,
    });

    if (!validateCurrentStep()) {
      console.warn("[PortfolioWizard] next blocked because validation failed");

      return;
    }

    setCurrentStep((previous) => {
      const next = Math.min(previous + 1, CONTENT_STEPS.length - 1);

      console.log("[PortfolioWizard] moving to next step", {
        from: previous,
        to: next,
      });

      return next;
    });
  }, [validateCurrentStep]);

  // ---------------------------------------------------------------------------
  // Previous step
  // ---------------------------------------------------------------------------

  const handleBack = useCallback(() => {
    console.log("[PortfolioWizard] back button clicked", {
      currentStep,
    });

    setError(null);

    setCurrentStep((previous) => {
      const next = Math.max(previous - 1, 0);

      console.log("[PortfolioWizard] moving to previous step", {
        from: previous,
        to: next,
      });

      return next;
    });
  }, []);

  // ---------------------------------------------------------------------------
  // Go to specific step
  // ---------------------------------------------------------------------------

  const handleStepChange = useCallback(
    (step: number) => {
      console.log("[PortfolioWizard] requested step change", {
        currentStep,
        requestedStep: step,
      });

      if (step > currentStep && !validateCurrentStep()) {
        console.warn(
          "[PortfolioWizard] step change blocked because validation failed",
        );

        return;
      }

      setError(null);
      setCurrentStep(step);
    },
    [currentStep, validateCurrentStep],
  );

  // ---------------------------------------------------------------------------
  // Final submit
  // ---------------------------------------------------------------------------

  const handleSubmit = useCallback(async () => {
    console.log("[PortfolioWizard] ===============================");
    console.log("[PortfolioWizard] FINAL SUBMIT STARTED");
    console.log("[PortfolioWizard] ===============================");

    setError(null);

    if (!validateCurrentStep()) {
      console.warn(
        "[PortfolioWizard] submit blocked because current step is invalid",
      );

      return;
    }

    setIsSubmitting(true);

    try {
      // -----------------------------------------------------------------------
      // Resume URL decision
      //
      // Priority:
      // 1. Auto-generated resume => ""
      // 2. Uploaded/attached resume => uploaded URL
      // 3. Otherwise => ""
      //
      // Existing DB resume is used as fallback in edit mode.
      // -----------------------------------------------------------------------

      let finalResumeUrl = "";

      if (autoGenerateResume) {
        console.log("[PortfolioWizard] resume strategy: AUTO GENERATE");

        finalResumeUrl = "";
      } else if (attachUploadedResume) {
        finalResumeUrl = (resumeUrl || data?.resumeUrl || "").trim();

        console.log("[PortfolioWizard] resume strategy: ATTACH UPLOADED", {
          resumeUrl,
          existingResumeUrl: data?.resumeUrl,
          finalResumeUrl,
        });
      } else {
        console.log("[PortfolioWizard] resume strategy: NO RESUME ATTACHED");

        finalResumeUrl = "";
      }

      // -----------------------------------------------------------------------
      // Keywords
      // -----------------------------------------------------------------------

      const keywords = seoKeywords
        .split(",")
        .map((keyword) => keyword.trim())
        .filter(Boolean);

      console.log("[PortfolioWizard] parsed SEO keywords", {
        keywords,
      });

      // -----------------------------------------------------------------------
      // Preserve existing design configuration
      //
      // IMPORTANT:
      // Never send empty {} here during edit.
      // -----------------------------------------------------------------------

      const componentSelection =
        (data?.componentSelection as
          | UpdatePortfolioDataInput["componentSelection"]
          | undefined) ?? {};

      const designPreferences =
        (data?.designPreferences as
          | UpdatePortfolioDataInput["designPreferences"]
          | undefined) ?? {};

      console.log(
        "[PortfolioWizard] preserving existing componentSelection",
        componentSelection,
      );

      console.log(
        "[PortfolioWizard] preserving existing designPreferences",
        designPreferences,
      );

      // -----------------------------------------------------------------------
      // Build final payload
      // -----------------------------------------------------------------------

      const payload = {
        portfolioId: portfolio.id,

        name: name.trim(),

        prompt: (promptLocked ? (data?.prompt ?? prompt) : prompt).trim(),

        avatarUrl: avatarUrl.trim(),
        phone: phone.trim(),
        linkedinUrl: linkedinUrl.trim(),
        githubUrl: githubUrl.trim(),

        headline: headline.trim(),
        about: about.trim(),

        skills,
        experience,
        projects,
        education,
        certificates,

        resumeUrl: finalResumeUrl,

        theme: data?.theme ?? "minimal",
        animations: data?.animations ?? true,

        componentSelection,
        designPreferences,

        seo: {
          title: seoTitle.trim(),
          description: seoDescription.trim(),
          keywords,
          noIndex: seoNoIndex,
        },
      };

      console.log("[PortfolioWizard] final payload", {
        ...payload,
        // Avoid dumping large portfolio arrays twice in console.
        experienceCount: experience.length,
        projectsCount: projects.length,
        educationCount: education.length,
        certificatesCount: certificates.length,
        skillsCount: skills.length,
      });

      // -----------------------------------------------------------------------
      // Save portfolio
      // -----------------------------------------------------------------------

      console.log("[PortfolioWizard] calling finalizePortfolioAction...");

      const result = await finalizePortfolioAction(payload);

      console.log("[PortfolioWizard] finalizePortfolioAction response", result);

      if (!result?.success) {
        throw new Error(result?.error ?? "Failed to save portfolio.");
      }

      console.log("[PortfolioWizard] portfolio saved successfully", {
        portfolioId: portfolio.id,
      });

      // -----------------------------------------------------------------------
      // Auto generate resume after portfolio has been saved
      // -----------------------------------------------------------------------

      if (autoGenerateResume) {
        console.log("[PortfolioWizard] starting automatic resume generation");

        setIsGeneratingResume(true);

        const generateResult = await generateAndAttachResume(portfolio.id);

        console.log(
          "[PortfolioWizard] generateAndAttachResume response",
          generateResult,
        );

        if (!generateResult?.success) {
          console.error(
            "[PortfolioWizard] resume generation failed",
            generateResult,
          );

          throw new Error(
            generateResult?.error ??
              "Portfolio saved, but resume generation failed.",
          );
        }

        if (generateResult.data?.resumeUrl) {
          const generatedUrl = generateResult.data.resumeUrl;

          console.log("[PortfolioWizard] generated resume URL received", {
            generatedUrl,
          });

          setResumeUrl(generatedUrl);
          setHasUploadedResume(true);
          setAttachUploadedResume(true);
          setAutoGenerateResume(false);
        }

        console.log("[PortfolioWizard] automatic resume generation completed");
      }

      // -----------------------------------------------------------------------
      // Success
      // -----------------------------------------------------------------------

      console.log("[PortfolioWizard] ===============================");
      console.log("[PortfolioWizard] FINAL SUBMIT SUCCESS");
      console.log("[PortfolioWizard] ===============================");

      router.refresh();
    } catch (err) {
      console.error("[PortfolioWizard] FINAL SUBMIT FAILED", err);

      const message =
        err instanceof Error
          ? err.message
          : "Something went wrong while saving the portfolio.";

      setError(message);
    } finally {
      setIsSubmitting(false);
      setIsGeneratingResume(false);

      console.log("[PortfolioWizard] submit loading states reset");
    }
  }, [
    autoGenerateResume,
    avatarUrl,
    certificates,
    data,
    education,
    experience,
    githubUrl,
    headline,
    linkedinUrl,
    name,
    about,
    portfolio.id,
    prompt,
    promptLocked,
    projects,
    resumeUrl,
    router,
    seoDescription,
    seoKeywords,
    seoNoIndex,
    seoTitle,
    skills,
    validateCurrentStep,
    phone,
    attachUploadedResume,
  ]);

  // ---------------------------------------------------------------------------
  // Current step component
  // ---------------------------------------------------------------------------

  const currentStepContent = useMemo(() => {
    console.log("[PortfolioWizard] rendering step content", {
      currentStep,
      step: CONTENT_STEPS[currentStep],
    });

    switch (currentStep) {
      case 0:
        return (
          <BasicsStep
            name={name}
            setName={setName}
            prompt={prompt}
            setPrompt={setPrompt}
            avatarUrl={avatarUrl}
            setAvatarUrl={setAvatarUrl}
            phone={phone}
            setPhone={setPhone}
            linkedinUrl={linkedinUrl}
            setLinkedinUrl={setLinkedinUrl}
            githubUrl={githubUrl}
            setGithubUrl={setGithubUrl}
            headline={headline}
            setHeadline={setHeadline}
            about={about}
            setAbout={setAbout}
            skills={skills}
            setSkills={setSkills}
            promptLocked={promptLocked}
          />
        );

      case 1:
        return (
          <ExperienceStep
            experience={experience}
            setExperience={setExperience}
          />
        );

      case 2:
        return <ProjectsStep projects={projects} setProjects={setProjects} />;

      case 3:
        return (
          <EducationStep education={education} setEducation={setEducation} />
        );

      case 4:
        return (
          <CertificatesStep
            certificates={certificates}
            setCertificates={setCertificates}
          />
        );

      case 5:
        return (
          <ResumeStep
            resumeUrl={resumeUrl}
            hasUploadedResume={hasUploadedResume}
            attachUploadedResume={attachUploadedResume}
            autoGenerateResume={autoGenerateResume}
            isUploadingResume={isUploadingResume}
            isParsingResume={isParsingResume}
            isGeneratingResume={isGeneratingResume}
            onResumeChange={handleResumeInputChange}
            onAttachUploadedResumeChange={handleAttachUploadedResumeChange}
            onAutoGenerateResumeChange={handleAutoGenerateResumeChange}
          />
        );

      case 6:
        return (
          <SeoStep
            seoTitle={seoTitle}
            setSeoTitle={setSeoTitle}
            seoDescription={seoDescription}
            setSeoDescription={setSeoDescription}
            seoKeywords={seoKeywords}
            setSeoKeywords={setSeoKeywords}
            seoNoIndex={seoNoIndex}
            setSeoNoIndex={setSeoNoIndex}
          />
        );

      default:
        console.warn("[PortfolioWizard] unknown step", currentStep);

        return null;
    }
  }, [
    currentStep,
    name,
    prompt,
    avatarUrl,
    phone,
    linkedinUrl,
    githubUrl,
    headline,
    about,
    skills,
    promptLocked,
    experience,
    projects,
    education,
    certificates,
    resumeUrl,
    hasUploadedResume,
    attachUploadedResume,
    autoGenerateResume,
    isUploadingResume,
    isParsingResume,
    isGeneratingResume,
    seoTitle,
    seoDescription,
    seoKeywords,
    seoNoIndex,
    handleResumeInputChange,
    handleAttachUploadedResumeChange,
    handleAutoGenerateResumeChange,
  ]);

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <div className="w-full">
      <div className="mb-8">
        <CreationModeSelect
          value={mode}
          onChange={(nextMode) => {
            console.log("[PortfolioWizard] creation mode changed", {
              from: mode,
              to: nextMode,
            });

            setMode(nextMode);
            setError(null);
          }}
        />
      </div>

      <div className="mb-8">
        <WizardProgress
          steps={CONTENT_STEPS}
          currentStep={currentStep}
          onStepChange={handleStepChange}
        />
      </div>

      {error && (
        <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      <div className="min-h-[400px]">{currentStepContent}</div>

      <div className="mt-10 flex items-center justify-between border-t pt-6">
        <Button
          type="button"
          variant="outline"
          onClick={handleBack}
          disabled={currentStep === 0 || isSubmitting}
        >
          Back
        </Button>

        {currentStep < CONTENT_STEPS.length - 1 ? (
          <Button type="button" onClick={handleNext} disabled={isSubmitting}>
            Continue
          </Button>
        ) : (
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={
              isSubmitting ||
              isUploadingResume ||
              isParsingResume ||
              isGeneratingResume
            }
          >
            {isSubmitting
              ? "Saving..."
              : isGeneratingResume
                ? "Generating Resume..."
                : "Save Portfolio"}
          </Button>
        )}
      </div>
    </div>
  );
}
