import type { PortfolioWizardProps } from "./types";

export function createId() {
  return crypto.randomUUID();
}

export function isPortfolioEmpty(data: PortfolioWizardProps["data"]) {
  if (!data) return true;
  const hasContent =
    (data.name && data.name.trim()) ||
    (data.headline && data.headline.trim()) ||
    (data.about && data.about.trim()) ||
    (data.skills && data.skills.length > 0) ||
    (data.projects && data.projects.length > 0) ||
    (data.experience && data.experience.length > 0);
  return !hasContent;
}
