"use server";

import { revalidatePath } from "next/cache";

import { requireProfile } from "@/lib/auth/require-profile";
import { requireUser } from "@/lib/auth/require-user";

import { portfolioService } from "@/services/portfolio/portfolio.service";
import { aiRequestService } from "@/services/portfolio/ai-request.service";
import { decideDesignWithGemini } from "@/lib/ai/decide-design";
import { updatePortfolioDataSchema } from "@/validations/portfolio-data.schema";

export async function finalizePortfolioAction(input: unknown) {
  try {
    await requireUser();
    const profile = await requireProfile();

    const parsed = updatePortfolioDataSchema.safeParse(input);
    if (!parsed.success) {
      return {
        success: false as const,
        message: "Invalid portfolio data.",
        fieldErrors: parsed.error.flatten().fieldErrors,
      };
    }

    const data = parsed.data;

    const portfolio = await portfolioService.getPortfolioForUser(
      data.portfolioId,
      profile.id,
    );

    if (!portfolio) {
      return { success: false as const, message: "Portfolio not found." };
    }

    // Prompt lock: agar DB mein pehle se prompt hai to override mat karo
    const existing = await portfolioService.getPortfolioWithData(
      data.portfolioId,
      profile.id,
    );
    const existingPrompt = (existing?.data?.prompt as string | null) ?? "";
    const finalPrompt =
      existingPrompt.trim().length > 0 ? existingPrompt : data.prompt;

    // AI design decision
    const design = await decideDesignWithGemini({
      prompt: finalPrompt,
      headline: data.headline,
      about: data.about,
    });

    if (design.usedAi) {
      await aiRequestService.recordUsage({
        portfolioId: data.portfolioId,
        requestType: "design_decision",
        model: "gemini-1.5-flash",
        inputTokens: design.inputTokens,
        outputTokens: design.outputTokens,
        latencyMs: design.latencyMs,
        status: "success",
      });
    }

    const result = await portfolioService.updatePortfolioData(
      data.portfolioId,
      profile.id,
      {
        ...data,
        prompt: finalPrompt,
        componentSelection: design.decision.componentSelection,
        designPreferences: design.decision.designPreferences,
      },
    );

    revalidatePath(`/dashboard/portfolios/${data.portfolioId}`);
    revalidatePath(`/dashboard/portfolios/${data.portfolioId}/edit`);

    return {
      success: true as const,
      data: result,
      designMeta: {
        usedAi: design.usedAi,
        componentSelection: design.decision.componentSelection,
        designPreferences: design.decision.designPreferences,
      },
    };
  } catch (error) {
    console.error("finalizePortfolioAction:", error);

    return {
      success: false as const,
      message:
        error instanceof Error
          ? error.message
          : "Unable to finalize portfolio.",
    };
  }
}